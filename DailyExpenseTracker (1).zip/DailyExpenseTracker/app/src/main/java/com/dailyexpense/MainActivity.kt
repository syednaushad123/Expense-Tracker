package com.dailyexpense
import android.Manifest
import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = (app as App).db.dao()
    val txs = dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val budgets = dao.budgets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun add(t: Tx) = viewModelScope.launch { dao.insert(t.copy(hash = Parser.hash(t))) }
    fun del(t: Tx) = viewModelScope.launch { dao.delete(t) }
    fun confirm(t: Tx) = viewModelScope.launch { dao.update(t.copy(pending = false)) }
    fun setCategory(t: Tx, c: String) = viewModelScope.launch {   // learns: future txns from this merchant use c
        dao.update(t.copy(category = c, pending = false)); dao.setRule(MerchantRule(t.merchant.uppercase(), c)) }
    fun setBudget(k: String, v: Double) = viewModelScope.launch { dao.setBudget(Budget(k, v)) }
    fun wipe() = viewModelScope.launch { dao.wipeTx(); dao.wipeBudgets(); dao.wipeRules() }
}

fun inr(x: Double) = "₹" + "%,.0f".format(x)
private val zone = ZoneId.systemDefault()
fun ms(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()
fun fmt(ts: Long) = Instant.ofEpochMilli(ts).atZone(zone).format(DateTimeFormatter.ofPattern("dd MMM, h:mm a"))
val palette = listOf(Color(0xFF6C5CE7), Color(0xFF00B894), Color(0xFFFD79A8), Color(0xFFFDCB6E), Color(0xFF0984E3),
    Color(0xFFE17055), Color(0xFF00CEC9), Color(0xFFB2BEC3))

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Root() }
            }
        }
    }
}

@Composable fun Root(vm: VM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf("Dashboard" to Icons.Default.Home, "Transactions" to Icons.Default.List,
        "Analytics" to Icons.Default.PieChart, "Budget" to Icons.Default.Savings, "Settings" to Icons.Default.Settings)
    Scaffold(bottomBar = {
        NavigationBar { items.forEachIndexed { i, (n, ic) ->
            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, n) },
                label = { Text(n, style = MaterialTheme.typography.labelSmall, maxLines = 1) }) } }
    }) { pad -> Box(Modifier.padding(pad)) { when (tab) {
        0 -> Dashboard(vm); 1 -> Transactions(vm); 2 -> Analytics(vm); 3 -> BudgetScreen(vm); else -> SettingsScreen(vm) } } }
}

@Composable fun Stat(label: String, v: String, mod: Modifier = Modifier) = Card(mod, shape = RoundedCornerShape(20.dp)) {
    Column(Modifier.padding(16.dp)) { Text(label, style = MaterialTheme.typography.labelMedium)
        Text(v, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }

fun byCat(l: List<Tx>) = l.filter { it.isExpense }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }

@Composable fun Dashboard(vm: VM) {
    val all by vm.txs.collectAsState(); val bud by vm.budgets.collectAsState()
    val now = LocalDate.now(); val d0 = ms(now); val m0 = ms(now.withDayOfMonth(1)); val pm0 = ms(now.withDayOfMonth(1).minusMonths(1))
    val ok = all.filter { !it.pending }
    val today = ok.filter { it.ts >= d0 }; val month = ok.filter { it.ts >= m0 }; val prev = ok.filter { it.ts in pm0 until m0 }
    val exp = month.filter { it.isExpense }.sumOf { it.amount }; val inc = month.filter { !it.isExpense }.sumOf { it.amount }
    val cats = byCat(month); val pc = byCat(prev)
    val top = cats.maxByOrNull { it.value }
    val mover = cats.filter { (pc[it.key] ?: 0.0) > 0 }.maxByOrNull { it.value / pc[it.key]!! }
    val limit = bud.firstOrNull { it.key == "TOTAL" }?.limit
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(now.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium)
            Text(inr(exp), fontSize = 40.sp, fontWeight = FontWeight.Bold); Text("spent this month") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Income", inr(inc), Modifier.weight(1f)); Stat("Saved", inr(inc - exp), Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Today spent", inr(today.filter { it.isExpense }.sumOf { it.amount }), Modifier.weight(1f))
            Stat("Today txns", "${today.size}", Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Avg / day", inr(exp / now.dayOfMonth), Modifier.weight(1f))
            Stat("Biggest txn", inr(month.filter { it.isExpense }.maxOfOrNull { it.amount } ?: 0.0), Modifier.weight(1f)) } }
        if (limit != null) item { Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) {
            Text(if (exp <= limit) "Within budget: ${inr(limit - exp)} left" else "Over budget by ${inr(exp - limit)}")
            LinearProgressIndicator(progress = { (exp / limit).toFloat().coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(top = 8.dp)) } } }
        item { Card(shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) {
            Text("Insights", fontWeight = FontWeight.Bold)
            top?.let { Text("📈 ${it.key} is your highest expense (${inr(it.value)})") }
            mover?.let { val p = ((it.value / pc[it.key]!! - 1) * 100).toInt()
                Text(if (p >= 0) "⚠️ ${it.key} is up $p% vs last month" else "💡 ${it.key} is down ${-p}% vs last month") }
            if (top == null) Text("Add or receive transactions to see insights") } } }
    }
}

@Composable fun CatPicker(cur: String, onPick: (String) -> Unit) {
    var o by remember { mutableStateOf(false) }
    Box { AssistChip(onClick = { o = true }, label = { Text(cur) })
        DropdownMenu(o, { o = false }) { CATS.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { o = false; onPick(c) }) } } }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Transactions(vm: VM) {
    val all by vm.txs.collectAsState(); var q by remember { mutableStateOf("") }; var adding by remember { mutableStateOf(false) }
    val list = all.filter { q.isBlank() || listOf(it.merchant, it.category, it.method, it.amount.toString(), fmt(it.ts)).any { s -> s.contains(q, true) } }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search merchant, amount, category, date, method") }, singleLine = true)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(list, key = { it.id }) { t -> Card(Modifier.fillMaxWidth().combinedClickable(onClick = {}, onLongClick = { vm.del(t) }), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(t.merchant, fontWeight = FontWeight.Bold)
                            CatPicker(t.category) { vm.setCategory(t, it) }
                            Text("${fmt(t.ts)} · ${t.method}", style = MaterialTheme.typography.bodySmall)
                            if (t.pending) TextButton({ vm.confirm(t) }) { Text("Confirm detected transaction") } }
                        Text((if (t.isExpense) "-" else "+") + inr(t.amount), fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            color = if (t.isExpense) Color(0xFFD63031) else Color(0xFF00B894)) } } }
                item { Text("Long-press a row to delete", Modifier.padding(8.dp), style = MaterialTheme.typography.bodySmall) } } }
        FloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Icon(Icons.Default.Add, "Add") }
    }
    if (adding) AddDialog({ adding = false }) { vm.add(it); adding = false }
}

@Composable fun AddDialog(dismiss: () -> Unit, save: (Tx) -> Unit) {
    var a by remember { mutableStateOf("") }; var m by remember { mutableStateOf("") }; var exp by remember { mutableStateOf(true) }
    var c by remember { mutableStateOf("Other") }; var pm by remember { mutableStateOf("Cash") }
    AlertDialog(onDismissRequest = dismiss, title = { Text("Add transaction") }, text = { Column {
        OutlinedTextField(a, { a = it }, label = { Text("Amount") }, singleLine = true)
        OutlinedTextField(m, { m = it; c = Parser.guess(it) }, label = { Text("Merchant / note") }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) { Text(if (exp) "Expense" else "Income"); Switch(exp, { exp = it }) }
        CatPicker(c) { c = it }
        Row { METHODS.take(3).forEach { FilterChip(pm == it, { pm = it }, { Text(it, maxLines = 1) }) } }
        Row { METHODS.drop(3).forEach { FilterChip(pm == it, { pm = it }, { Text(it, maxLines = 1) }) } } } },
        confirmButton = { TextButton({ a.toDoubleOrNull()?.let { save(Tx(amount = it, isExpense = exp, merchant = m.ifBlank { "Manual" },
            category = c, method = pm, ts = System.currentTimeMillis())) } }) { Text("Save") } },
        dismissButton = { TextButton(dismiss) { Text("Cancel") } })
}

@Composable fun Analytics(vm: VM) {
    val all by vm.txs.collectAsState()
    val now = LocalDate.now(); val m0 = ms(now.withDayOfMonth(1)); val pm0 = ms(now.withDayOfMonth(1).minusMonths(1))
    val month = all.filter { !it.pending && it.ts >= m0 && it.isExpense }; val prev = byCat(all.filter { it.ts in pm0 until m0 })
    val cats = byCat(month).entries.sortedByDescending { it.value }; val total = cats.sumOf { it.value }
    val method = month.groupBy { it.method }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Where your money goes", style = MaterialTheme.typography.titleLarge)
            Canvas(Modifier.fillMaxWidth().height(200.dp).padding(16.dp)) {
                var start = -90f; val sz = Size(size.height, size.height); val tl = androidx.compose.ui.geometry.Offset((size.width - size.height) / 2, 0f)
                cats.forEachIndexed { i, e -> val sw = (e.value / total * 360).toFloat()
                    drawArc(palette[i % palette.size], start, sw, false, tl, sz, style = Stroke(40f)); start += sw } } }
        items(cats.size) { i -> val e = cats[i]; val n = month.count { it.category == e.key }; val p = prev[e.key]
            Column { Row { Text("${e.key} · $n txns", Modifier.weight(1f)); Text("${inr(e.value)}  ${(e.value / total * 100).toInt()}%") }
                LinearProgressIndicator(progress = { (e.value / total).toFloat() }, Modifier.fillMaxWidth(), color = palette[i % palette.size])
                if (p != null && p > 0) { val d = ((e.value / p - 1) * 100).toInt(); Text(if (d >= 0) "▲ $d% vs last month" else "▼ ${-d}% vs last month", style = MaterialTheme.typography.bodySmall) } } }
        item { Text("Payment methods", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp)) }
        items(method.size) { Text("${method[it].key}: ${inr(method[it].value)}") }
    }
}

@Composable fun BudgetScreen(vm: VM) {
    val all by vm.txs.collectAsState(); val bud by vm.budgets.collectAsState()
    val m0 = ms(LocalDate.now().withDayOfMonth(1)); val spent = byCat(all.filter { !it.pending && it.ts >= m0 })
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Budgets (monthly)", style = MaterialTheme.typography.titleLarge) }
        items(listOf("TOTAL") + CATS) { k ->
            val lim = bud.firstOrNull { it.key == k }?.limit; val s = if (k == "TOTAL") spent.values.sum() else spent[k] ?: 0.0
            var txt by remember(lim) { mutableStateOf(lim?.toLong()?.toString() ?: "") }
            Column { OutlinedTextField(txt, { txt = it; it.toDoubleOrNull()?.let { v -> vm.setBudget(k, v) } },
                label = { Text(if (k == "TOTAL") "Total monthly budget" else k) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (lim != null && lim > 0) { LinearProgressIndicator(progress = { (s / lim).toFloat().coerceIn(0f, 1f) }, Modifier.fillMaxWidth(),
                    color = if (s > lim) Color.Red else if (s > lim * 0.8) Color(0xFFFDCB6E) else MaterialTheme.colorScheme.primary)
                    Text(if (s > lim) "⚠️ Exceeded by ${inr(s - lim)}" else if (s > lim * 0.8) "⚠️ ${inr(s)} of ${inr(lim)} used" else "${inr(s)} of ${inr(lim)}",
                        style = MaterialTheme.typography.bodySmall) } } }
    }
}

@Composable fun SettingsScreen(vm: VM) {
    val ctx = androidx.compose.ui.platform.LocalContext.current; val all by vm.txs.collectAsState()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.bufferedWriter()?.use { w ->
            w.write("Date,Type,Amount,Merchant,Category,Method,Note\n")
            all.forEach { t -> w.write("${fmt(t.ts)},${if (t.isExpense) "Expense" else "Income"},${t.amount},\"${t.merchant}\",${t.category},${t.method},\"${t.note}\"\n") } } } }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)
        Button({ perm.launch(Manifest.permission.RECEIVE_SMS) }) { Text("Enable SMS auto-detection") }
        Button({ export.launch("expenses.csv") }) { Text("Export CSV (also works as backup)") }
        OutlinedButton({ confirm = true }) { Text("Delete all data") }
        Text("Privacy: all data stays on this device. SMS are parsed locally; nothing is uploaded. OTPs, PINs and card numbers are never stored.",
            style = MaterialTheme.typography.bodySmall)
    }
    if (confirm) AlertDialog({ confirm = false }, confirmButton = { TextButton({ vm.wipe(); confirm = false }) { Text("Delete") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }, title = { Text("Delete everything?") })
}

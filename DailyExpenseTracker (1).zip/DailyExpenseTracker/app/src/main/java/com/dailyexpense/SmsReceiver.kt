package com.dailyexpense
import android.content.*
import android.provider.Telephony
import kotlinx.coroutines.*

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val ts = msgs.firstOrNull()?.timestampMillis ?: System.currentTimeMillis()
        val dao = (c.applicationContext as App).db.dao()
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Parser.parse(body, ts)?.let { t ->
                    val learned = dao.rule(t.merchant.uppercase())
                    dao.insert(if (learned != null) t.copy(category = learned) else t)   // duplicates ignored by unique hash
                }
            } finally { pr.finish() }
        }
    }
}

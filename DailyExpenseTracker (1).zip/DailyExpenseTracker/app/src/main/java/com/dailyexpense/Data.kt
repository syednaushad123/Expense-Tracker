package com.dailyexpense
import android.app.Application
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tx", indices = [Index(value = ["hash"], unique = true)])
data class Tx(@PrimaryKey(autoGenerate = true) val id: Long = 0, val amount: Double, val isExpense: Boolean,
    val merchant: String, val category: String, val method: String, val ts: Long,
    val note: String = "", val hash: String = "", val pending: Boolean = false)
@Entity data class Budget(@PrimaryKey val key: String, val limit: Double)
@Entity data class MerchantRule(@PrimaryKey val merchant: String, val category: String)

@Dao interface TxDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(t: Tx): Long
    @Update suspend fun update(t: Tx)
    @Delete suspend fun delete(t: Tx)
    @Query("SELECT * FROM tx ORDER BY ts DESC") fun all(): Flow<List<Tx>>
    @Query("SELECT * FROM Budget") fun budgets(): Flow<List<Budget>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setBudget(b: Budget)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setRule(r: MerchantRule)
    @Query("SELECT category FROM MerchantRule WHERE merchant = :m") suspend fun rule(m: String): String?
    @Query("DELETE FROM tx") suspend fun wipeTx()
    @Query("DELETE FROM Budget") suspend fun wipeBudgets()
    @Query("DELETE FROM MerchantRule") suspend fun wipeRules()
}
@Database(entities = [Tx::class, Budget::class, MerchantRule::class], version = 1, exportSchema = false)
abstract class DB : RoomDatabase() { abstract fun dao(): TxDao }

class App : Application() {
    val db by lazy { Room.databaseBuilder(this, DB::class.java, "expense.db").build() }
}

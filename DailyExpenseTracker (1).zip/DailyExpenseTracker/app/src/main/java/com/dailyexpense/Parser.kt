package com.dailyexpense

val CATS = listOf("Food & Dining", "Grocery", "Transport", "Fuel", "Rent / Home", "Utilities", "Mobile / Internet",
    "Shopping", "Travel", "Health", "Entertainment", "Investments", "Education", "EMI / Loan", "Family", "Bank Charges", "Other")
val METHODS = listOf("UPI", "Credit Card", "Debit Card", "Cash", "Bank Transfer", "Wallet")

object Parser {
    private val I = RegexOption.IGNORE_CASE
    private val amt = Regex("""(?:INR|Rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)""", I)
    private val debit = Regex("""debited|spent|paid|sent|withdrawn|purchase|transaction of|payment of""", I)
    private val credit = Regex("""credited|received|deposited""", I)
    private val merch = Regex("""\b(?:at|to|from)\s+([A-Za-z0-9&@._ ]{2,30}?)(?=\s+(?:on|via|ref|using|avl|upi|towards)\b|[.,…\-]|$)""", I)
    private val kw = mapOf(
        "Food & Dining" to listOf("swiggy", "zomato", "restaurant", "cafe", "dominos", "mcdonald", "kfc"),
        "Grocery" to listOf("bigbasket", "blinkit", "zepto", "dmart", "grocery", "instamart"),
        "Transport" to listOf("uber", "ola", "rapido", "metro", "irctc", "redbus"),
        "Fuel" to listOf("petrol", "fuel", "hpcl", "bpcl", "iocl", "shell"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio", "meesho"),
        "Utilities" to listOf("electricity", "bescom", "water", "gas", "bill"),
        "Mobile / Internet" to listOf("jio", "airtel", "vodafone", "vi ", "broadband"),
        "Entertainment" to listOf("netflix", "spotify", "hotstar", "bookmyshow", "prime"),
        "Health" to listOf("pharmacy", "apollo", "hospital", "medplus", "1mg"),
        "Investments" to listOf("zerodha", "groww", "mutual fund", "sip"),
        "EMI / Loan" to listOf("emi", "loan"),
        "Bank Charges" to listOf("charges", "penalty", "fee"),
        "Travel" to listOf("makemytrip", "goibibo", "airline", "indigo", "hotel"))

    fun guess(m: String): String { val l = m.lowercase(); return kw.entries.firstOrNull { e -> e.value.any { it in l } }?.key ?: "Other" }
    fun hash(t: Tx) = "${t.amount}|${t.isExpense}|${t.ts / 600_000}"   // same amount within ~10 min = duplicate

    /** Returns null for OTPs / non-transactions. pending=true when merchant is unknown (ask user to confirm). */
    fun parse(body: String, ts: Long): Tx? {
        if (body.contains("OTP", true)) return null
        val a = amt.find(body)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        val expense = when { credit.containsMatchIn(body) -> false; debit.containsMatchIn(body) -> true; else -> return null }
        val m = merch.find(body)?.groupValues?.get(1)?.trim()
        val l = body.lowercase()
        val method = when { "upi" in l -> "UPI"; "credit card" in l -> "Credit Card"; "card" in l -> "Debit Card"; else -> "Bank Transfer" }
        val name = m ?: "Unknown"
        val t = Tx(amount = a, isExpense = expense, merchant = name, category = if (expense) guess(name) else "Other",
            method = method, ts = ts, pending = m == null)
        return t.copy(hash = hash(t))
    }
}
